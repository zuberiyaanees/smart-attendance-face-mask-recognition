# Smart Attendance — Mask + Face Recognition V5 Final

A Java 17 + Spring Boot web application for academic smart attendance demonstrations. It registers students, captures masked-face samples, extracts an upper-face LBP descriptor, compares a live webcam frame against all enrolled students, requires repeated matching frames, and records one attendance row per student per day.

## Important: what identifies a student?
The mask is NOT the identity. During enrollment, the system stores multiple images of the student's visible upper-face region. During recognition, the live upper-face image is converted into an LBP histogram descriptor and compared with the descriptors of all enrolled students. The best candidate is accepted only when it is below the configured threshold and sufficiently separated from the next-best candidate. The browser then requires 3 consecutive matches before asking the server to mark attendance.

This is a classical computer-vision project implementation, not a biometric-security certification. A determined attacker could still spoof a simple camera-based system. A production deployment should add a modern face-embedding model, robust liveness/presentation-attack detection, encryption/access controls, consent and privacy controls, and measured false-match/false-non-match testing on the real classroom camera and masks.

## The bug fixed in this build
The previous recognition path passed an already-grayscale face image into `cvtColor(..., COLOR_BGR2GRAY)`, producing OpenCV's `Invalid number of channels in input image`. This build normalizes the image channel count before feature extraction and keeps enrollment/training/recognition on the same grayscale pipeline.

## Usage
1. Add every student with a unique Student ID.
2. Select a student and start the camera.
3. Wear the normal mask and capture up to 40 samples with small pose/lighting changes.
4. Click **Train Model** after all required students are enrolled.
5. Click **Start Recognition**.
6. The system compares the live face against all enrolled students.
7. The same identity must be returned in 3 consecutive frames before attendance is marked.
8. **Today's Attendance** shows the actual saved record. The recognition panel also says **ATTENDANCE MARKED** or **ALREADY MARKED TODAY**.
9. If a student's samples need to be replaced, use **Clear Samples**, capture again, and train again.

## Run
Requires JDK 17+.

Windows PowerShell:
```powershell
.\mvnw.cmd spring-boot:run
```
Then open http://localhost:8080

## APIs
GET  /api/students
POST /api/students
POST /api/enroll/{studentId} (multipart file=file)
DELETE /api/enroll/{studentId}
GET /api/enroll/{studentId}/count
POST /api/train
POST /api/recognize (multipart file=file)
POST /api/attendance/mark
GET /api/attendance/today
GET /api/attendance/export

## Data
- Student/attendance database: H2 file database under `data/`
- Face samples: `data/faces/<studentId>/`
- Trained model: `data/models/lbp-model.bin`

## Accuracy note
There is no honest fixed accuracy percentage without testing a representative dataset. Masked face recognition can be harder than unmasked recognition, and false matches and false non-matches are both possible. Test the actual camera, masks, lighting, pose, and student population before any real deployment.
