package com.smartattendance;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api")
public class AttendanceController {
    private final StudentRepository students;
    private final AttendanceRepository attendance;
    private final FaceService faces;

    public AttendanceController(StudentRepository students, AttendanceRepository attendance, FaceService faces){
        this.students=students; this.attendance=attendance; this.faces=faces;
    }

    @GetMapping("/students")
    public List<Student> students(){ return students.findAll(); }

    @PostMapping("/students")
    public Student add(@RequestBody Map<String,String> body){
        String sid=body.get("studentId"), name=body.get("name");
        if(sid==null||name==null||sid.isBlank()||name.isBlank()) throw new IllegalArgumentException("Student ID and name are required");
        sid=sid.trim();
        if(students.findByStudentId(sid).isPresent()) throw new IllegalArgumentException("Student ID already exists: "+sid);
        return students.save(new Student(sid,name.trim(),body.getOrDefault("className","")));
    }

    @PostMapping(value="/enroll/{studentId}", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String,Object> enroll(@PathVariable String studentId,@RequestParam("file") MultipartFile file)throws Exception{
        students.findByStudentId(studentId).orElseThrow(()->new IllegalArgumentException("Student not found"));
        int n=faces.enroll(studentId,file);
        return Map.of("ok",true,"studentId",studentId,"samples",n);
    }

    @DeleteMapping("/enroll/{studentId}")
    public Map<String,Object> clearEnrollment(@PathVariable String studentId)throws Exception{
        students.findByStudentId(studentId).orElseThrow(()->new IllegalArgumentException("Student not found"));
        faces.clearSamples(studentId);
        return Map.of("ok",true,"message","Enrollment samples cleared. Capture new samples and train again.");
    }

    @GetMapping("/enroll/{studentId}/count")
    public Map<String,Object> enrollmentCount(@PathVariable String studentId)throws Exception{
        students.findByStudentId(studentId).orElseThrow(()->new IllegalArgumentException("Student not found"));
        return Map.of("studentId",studentId,"samples",faces.sampleCount(studentId));
    }

    @PostMapping("/train")
    public Map<String,Object> train()throws Exception{
        faces.train();
        return Map.of("ok",true,"message","Model trained successfully. Recognition can now compare against enrolled students.");
    }

    @PostMapping(value="/recognize", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String,Object> recognize(@RequestParam("file") MultipartFile file)throws Exception{
        FaceService.Recognition r=faces.recognize(file);
        if(r.studentId().isBlank()) {
            return Map.of("recognized",false,"message","No reliable identity match. The face may be unknown, unclear, or too close to another enrolled student.",
                    "distance",r.distance(),"secondBestDistance",r.secondBestDistance());
        }
        Student st=students.findByStudentId(r.studentId()).orElse(null);
        if(st==null) return Map.of("recognized",false,"message","Matched ID is not registered");
        return Map.of("recognized",true,"studentId",st.getStudentId(),"name",st.getName(),
                "confidenceDistance",r.distance(),"secondBestDistance",r.secondBestDistance());
    }

    @PostMapping("/attendance/mark")
    public Map<String,Object> mark(@RequestBody Map<String,String> body){
        String sid=body.get("studentId");
        if(sid==null||sid.isBlank()) throw new IllegalArgumentException("Student ID is required");
        Student st=students.findByStudentId(sid.trim()).orElseThrow(()->new IllegalArgumentException("Student not found"));
        boolean already=attendance.existsByStudentIdAndAttendanceDate(st.getStudentId(),LocalDate.now());
        double distance = 0.0;
        try { distance = Double.parseDouble(body.getOrDefault("confidenceDistance", "0.0")); } catch (NumberFormatException ignored) {}
        if(!already) attendance.save(new Attendance(st.getStudentId(),st.getName(),"MASKED_FACE",distance));
        return Map.of("ok",true,"studentId",st.getStudentId(),"name",st.getName(),"attendanceMarked",!already,"alreadyMarked",already);
    }

    @GetMapping("/attendance/today")
    public List<Attendance> today(){return attendance.findAllByAttendanceDateOrderByMarkedAtDesc(LocalDate.now());}

    @GetMapping("/attendance/export")
    public List<Attendance> export(){return today();}
}
