package com.smartattendance;

import nu.pattern.OpenCV;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartAttendanceApplication {
    public static void main(String[] args) {
        OpenCV.loadLocally();
        SpringApplication.run(SmartAttendanceApplication.class, args);
    }
}
