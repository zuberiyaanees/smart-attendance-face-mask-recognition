package com.smartattendance;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(Exception.class)
    ResponseEntity<Map<String,Object>> handle(Exception e){
        String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
        return ResponseEntity.badRequest().body(Map.of("ok",false,"error",msg));
    }
}
