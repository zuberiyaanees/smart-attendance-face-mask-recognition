package com.smartattendance;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.*;
public interface AttendanceRepository extends JpaRepository<Attendance,Long>{
    boolean existsByStudentIdAndAttendanceDate(String studentId, LocalDate date);
    List<Attendance> findAllByAttendanceDateOrderByMarkedAtDesc(LocalDate date);
}
