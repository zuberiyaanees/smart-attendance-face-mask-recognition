package com.smartattendance;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="students")
public class Student {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(unique=true, nullable=false) private String studentId;
    @Column(nullable=false) private String name;
    private String className;
    private LocalDateTime createdAt = LocalDateTime.now();

    public Student() {}
    public Student(String studentId, String name, String className) {
        this.studentId=studentId; this.name=name; this.className=className;
    }
    public Long getId(){return id;}
    public String getStudentId(){return studentId;}
    public void setStudentId(String v){studentId=v;}
    public String getName(){return name;}
    public void setName(String v){name=v;}
    public String getClassName(){return className;}
    public void setClassName(String v){className=v;}
    public LocalDateTime getCreatedAt(){return createdAt;}
}
