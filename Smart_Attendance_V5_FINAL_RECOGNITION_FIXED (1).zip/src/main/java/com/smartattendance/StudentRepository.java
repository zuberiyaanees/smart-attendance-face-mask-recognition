package com.smartattendance;
import org.springframework.data.jpa.repository.JpaRepository;
public interface StudentRepository extends JpaRepository<Student,Long>{
    java.util.Optional<Student> findByStudentId(String studentId);
}
