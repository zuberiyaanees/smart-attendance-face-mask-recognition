package com.smartattendance;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="attendance", uniqueConstraints=@UniqueConstraint(columnNames={"studentId","attendanceDate"}))
public class Attendance {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String studentId;
    private String studentName;
    private LocalDate attendanceDate;
    private LocalDateTime markedAt;
    private String mode;
    private Double confidence;

    public Attendance(){}
    public Attendance(String sid,String name,String mode,double confidence){
        this.studentId=sid; this.studentName=name; this.attendanceDate=LocalDate.now();
        this.markedAt=LocalDateTime.now(); this.mode=mode; this.confidence=confidence;
    }
    public Long getId(){return id;}
    public String getStudentId(){return studentId;}
    public String getStudentName(){return studentName;}
    public LocalDate getAttendanceDate(){return attendanceDate;}
    public LocalDateTime getMarkedAt(){return markedAt;}
    public String getMode(){return mode;}
    public Double getConfidence(){return confidence;}
}
