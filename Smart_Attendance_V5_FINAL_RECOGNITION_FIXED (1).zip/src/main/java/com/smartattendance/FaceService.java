package com.smartattendance;

import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;
import java.util.*;

@Service
public class FaceService {
    private final Path facesRoot = Paths.get("data/faces");
    private final Path modelPath = Paths.get("data/models/lbp-model.bin");
    private final CascadeClassifier faceCascade;

    private static final int FACE_SIZE = 160;
    private static final double MATCH_THRESHOLD = 0.42;
    private static final double MIN_BEST_VS_SECOND_MARGIN = 0.025;

    public FaceService() throws IOException {
        Files.createDirectories(facesRoot);
        Files.createDirectories(modelPath.getParent());

        Path cascadePath = Paths.get("data/models/haarcascade_frontalface_default.xml");
        if (!Files.exists(cascadePath)) {
            try (InputStream in = getClass().getResourceAsStream("/haarcascade_frontalface_default.xml")) {
                if (in == null) throw new IOException("Face detector model is missing from the project.");
                Files.copy(in, cascadePath, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        faceCascade = new CascadeClassifier(cascadePath.toString());
        if (faceCascade.empty()) throw new IOException("Could not load OpenCV face detector.");
    }

    public synchronized int enroll(String studentId, MultipartFile file) throws Exception {
        Mat image = Imgcodecs.imdecode(new MatOfByte(file.getBytes()), Imgcodecs.IMREAD_COLOR);
        Mat face = extractMaskedFace(image);
        image.release();
        if (face.empty()) {
            throw new IllegalArgumentException("Face not detected. Keep your face centered, well lit, and wear the mask normally.");
        }

        Path dir = facesRoot.resolve(studentId);
        Files.createDirectories(dir);
        long count;
        try (var stream = Files.list(dir)) {
            count = stream.filter(p -> p.toString().toLowerCase().endsWith(".png")).count();
        }
        if (count >= 40) {
            face.release();
            throw new IllegalArgumentException("Maximum 40 samples reached for " + studentId);
        }

        Path output = dir.resolve(String.format("%03d.png", count + 1));
        Imgcodecs.imwrite(output.toString(), face);
        face.release();
        return (int) count + 1;
    }

    public synchronized int sampleCount(String studentId) throws IOException {
        Path dir = facesRoot.resolve(studentId);
        if (!Files.exists(dir)) return 0;
        try (var stream = Files.list(dir)) {
            return (int) stream.filter(p -> p.toString().toLowerCase().endsWith(".png")).count();
        }
    }

    public synchronized void clearSamples(String studentId) throws IOException {
        Path dir = facesRoot.resolve(studentId);
        if (!Files.exists(dir)) return;
        try (var stream = Files.list(dir)) {
            for (Path p : stream.filter(x -> x.toString().toLowerCase().endsWith(".png")).toList()) {
                Files.deleteIfExists(p);
            }
        }
        Files.deleteIfExists(modelPath);
    }

    public synchronized void train() throws Exception {
        List<ModelEntry> entries = new ArrayList<>();

        try (var studentDirs = Files.list(facesRoot)) {
            for (Path dir : studentDirs.filter(Files::isDirectory).toList()) {
                String studentId = dir.getFileName().toString();
                try (var images = Files.list(dir)) {
                    for (Path p : images.filter(x -> x.toString().toLowerCase().endsWith(".png")).toList()) {
                        Mat image = Imgcodecs.imread(p.toString(), Imgcodecs.IMREAD_GRAYSCALE);
                        if (!image.empty()) {
                            entries.add(new ModelEntry(studentId, lbpDescriptor(image)));
                        }
                        image.release();
                    }
                }
            }
        }

        if (entries.isEmpty()) throw new IllegalStateException("No face samples found. Enroll students first.");

        try (DataOutputStream out = new DataOutputStream(
                new BufferedOutputStream(Files.newOutputStream(modelPath)))) {
            out.writeInt(2);
            out.writeInt(entries.size());
            for (ModelEntry e : entries) {
                out.writeUTF(e.studentId());
                out.writeInt(e.descriptor().length);
                for (double value : e.descriptor()) out.writeDouble(value);
            }
        }
    }

    public synchronized Recognition recognize(MultipartFile file) throws Exception {
        if (!Files.exists(modelPath)) return new Recognition("", Double.MAX_VALUE, Double.MAX_VALUE);

        Mat image = Imgcodecs.imdecode(new MatOfByte(file.getBytes()), Imgcodecs.IMREAD_COLOR);
        Mat face = extractMaskedFace(image);
        image.release();
        if (face.empty()) return new Recognition("", Double.MAX_VALUE, Double.MAX_VALUE);

        // extractMaskedFace() deliberately returns a single-channel grayscale Mat.
        // The previous build called cvtColor(BGR2GRAY) here a second time, which
        // caused: "Invalid number of channels in input image".
        Mat gray = toGray(face);
        double[] query = lbpDescriptor(gray);
        gray.release();
        face.release();

        String bestStudent = "";
        double bestDistance = Double.MAX_VALUE;
        double secondBest = Double.MAX_VALUE;

        try (DataInputStream in = new DataInputStream(
                new BufferedInputStream(Files.newInputStream(modelPath)))) {
            int version = in.readInt();
            if (version != 2) throw new IOException("Face model is from an older build. Clear samples, capture again, and train the model.");
            int count = in.readInt();

            for (int i = 0; i < count; i++) {
                String studentId = in.readUTF();
                int length = in.readInt();
                double[] descriptor = new double[length];
                for (int j = 0; j < length; j++) descriptor[j] = in.readDouble();

                double distance = chiSquare(query, descriptor);
                if (distance < bestDistance) {
                    secondBest = bestDistance;
                    bestDistance = distance;
                    bestStudent = studentId;
                } else if (distance < secondBest) {
                    secondBest = distance;
                }
            }
        }

        boolean thresholdPass = bestDistance <= MATCH_THRESHOLD;
        boolean marginPass = secondBest == Double.MAX_VALUE || (secondBest - bestDistance) >= MIN_BEST_VS_SECOND_MARGIN;
        if (!thresholdPass || !marginPass) {
            return new Recognition("", bestDistance, secondBest);
        }
        return new Recognition(bestStudent, bestDistance, secondBest);
    }

    private Mat toGray(Mat input) {
        if (input.channels() == 1) {
            Mat gray = input.clone();
            Imgproc.equalizeHist(gray, gray);
            return gray;
        }
        Mat gray = new Mat();
        Imgproc.cvtColor(input, gray, Imgproc.COLOR_BGR2GRAY);
        Imgproc.equalizeHist(gray, gray);
        return gray;
    }

    private Mat extractMaskedFace(Mat image) {
        if (image == null || image.empty()) return new Mat();

        Mat gray = toGray(image);
        MatOfRect faces = new MatOfRect();
        faceCascade.detectMultiScale(gray, faces, 1.08, 4, 0, new Size(60, 60), new Size());
        Rect[] detected = faces.toArray();

        if (detected.length == 0) {
            gray.release();
            faces.release();
            return new Mat();
        }

        Rect best = Arrays.stream(detected)
                .max(Comparator.comparingInt(r -> r.width * r.height))
                .orElse(detected[0]);

        int x = Math.max(0, best.x);
        int y = Math.max(0, best.y);
        int width = Math.min(best.width, image.cols() - x);
        int upperHeight = Math.max(40, (int) (best.height * 0.68));
        upperHeight = Math.min(upperHeight, image.rows() - y);
        if (width <= 0 || upperHeight <= 0) {
            gray.release(); faces.release(); return new Mat();
        }

        Rect upper = new Rect(x, y, width, upperHeight);
        Mat crop = new Mat(image, upper);
        Mat resized = new Mat();
        Imgproc.resize(crop, resized, new Size(FACE_SIZE, FACE_SIZE), 0, 0, Imgproc.INTER_AREA);

        Mat result = toGray(resized);
        gray.release();
        faces.release();
        crop.release();
        resized.release();
        return result;
    }

    private double[] lbpDescriptor(Mat gray) {
        if (gray.channels() != 1) throw new IllegalArgumentException("Internal face image must be grayscale.");
        int width = gray.cols(), height = gray.rows(), cells = 4;
        int cellWidth = Math.max(1, width / cells), cellHeight = Math.max(1, height / cells);
        double[] descriptor = new double[cells * cells * 256];

        for (int y = 1; y < height - 1; y++) {
            for (int x = 1; x < width - 1; x++) {
                int center = (int) gray.get(y, x)[0];
                int code = 0;
                if (gray.get(y - 1, x - 1)[0] >= center) code |= 1;
                if (gray.get(y - 1, x)[0] >= center) code |= 2;
                if (gray.get(y - 1, x + 1)[0] >= center) code |= 4;
                if (gray.get(y, x + 1)[0] >= center) code |= 8;
                if (gray.get(y + 1, x + 1)[0] >= center) code |= 16;
                if (gray.get(y + 1, x)[0] >= center) code |= 32;
                if (gray.get(y + 1, x - 1)[0] >= center) code |= 64;
                if (gray.get(y, x - 1)[0] >= center) code |= 128;

                int cellX = Math.min(cells - 1, x / cellWidth);
                int cellY = Math.min(cells - 1, y / cellHeight);
                descriptor[(cellY * cells + cellX) * 256 + code]++;
            }
        }

        for (int c = 0; c < cells * cells; c++) {
            double sum = 0;
            int start = c * 256;
            for (int i = 0; i < 256; i++) sum += descriptor[start + i];
            if (sum > 0) for (int i = 0; i < 256; i++) descriptor[start + i] /= sum;
        }
        return descriptor;
    }

    private double chiSquare(double[] a, double[] b) {
        int n = Math.min(a.length, b.length);
        double total = 0;
        for (int i = 0; i < n; i++) {
            double denom = a[i] + b[i];
            if (denom > 1e-12) {
                double diff = a[i] - b[i];
                total += (diff * diff) / denom;
            }
        }
        return total / n;
    }

    public record Recognition(String studentId, double distance, double secondBestDistance) {}
    private record ModelEntry(String studentId, double[] descriptor) {}
}
