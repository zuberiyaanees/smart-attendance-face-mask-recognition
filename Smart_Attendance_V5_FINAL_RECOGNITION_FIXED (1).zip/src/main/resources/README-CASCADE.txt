The application expects data/models/haarcascade_frontalface_default.xml. A standard OpenCV Haar cascade is included by the build script when available.
