@ECHO OFF
SETLOCAL
SET "MAVEN_VERSION=3.9.11"
SET "MAVEN_HOME=%USERPROFILE%\.smart-attendance-maven\apache-maven-%MAVEN_VERSION%"
SET "MAVEN_ZIP=%USERPROFILE%\.smart-attendance-maven\apache-maven-%MAVEN_VERSION%-bin.zip"
SET "MAVEN_URL=https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/%MAVEN_VERSION%/apache-maven-%MAVEN_VERSION%-bin.zip"

IF EXIST "%MAVEN_HOME%\bin\mvn.cmd" GOTO RUN_MAVEN

ECHO Maven %MAVEN_VERSION% is not installed. Downloading it automatically...
IF NOT EXIST "%USERPROFILE%\.smart-attendance-maven" MKDIR "%USERPROFILE%\.smart-attendance-maven"

IF NOT EXIST "%MAVEN_ZIP%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%MAVEN_URL%' -OutFile '%MAVEN_ZIP%'"
  IF ERRORLEVEL 1 (
    ECHO Failed to download Maven.
    ECHO Check your internet connection and try again.
    EXIT /B 1
  )
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%MAVEN_ZIP%' -DestinationPath '%USERPROFILE%\.smart-attendance-maven' -Force"
IF ERRORLEVEL 1 (
  ECHO Failed to extract Maven.
  EXIT /B 1
)

:RUN_MAVEN
CALL "%MAVEN_HOME%\bin\mvn.cmd" %*
ENDLOCAL
